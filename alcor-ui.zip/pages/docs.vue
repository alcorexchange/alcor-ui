<script>
export default {
  fetch({ redirect }) {
    redirect('https://docs.alcor.exchange')
  }
}
</script>
