<template lang="pug">
  div
</template>

<script>
export default {
  layout: 'test'
}
</script>
