<template lang="pug">
el-card
  .lead Second
</template>
