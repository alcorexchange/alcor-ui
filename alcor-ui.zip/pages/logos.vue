<template lang="pug">
.row
  .col
    .row
      .col
        .display-4 Alcor Project logo

    .row.mt-4
      .col
        .lead White
        img(height="100" src="~/assets/logos/alcorblack.svg")

    .row.mt-4
      .col
        .lead Black
        img(height="100" src="~/assets/logos/alcorwhite.svg")

  .col
    .row
      .col
        .display-4 Icons

    .row.mt-4
      .col
        img(height="50" src="/android-chrome-512x512.png")

    .row.mt-4
      .col
        img(height="100" src="/black.png")

</template>
