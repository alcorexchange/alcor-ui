export class pToken {
  CONTRACTS = {
    PETH: 'eth.pTokens'
  }

  constructor(symbol) {
    this.symbol = symbol
  }
}

export class IBCToken {
  constructor(symbol) {
    this.symbol = symbol
  }
}
