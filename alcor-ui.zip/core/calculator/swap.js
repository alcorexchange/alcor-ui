export function getEstimatedTotalOutput() {

}
