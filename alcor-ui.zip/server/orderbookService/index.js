import { main } from './start'
main()
