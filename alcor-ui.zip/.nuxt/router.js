import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _1241c0de = () => interopDefault(import('..\\pages\\about.vue' /* webpackChunkName: "pages/about" */))
const _304102b1 = () => interopDefault(import('..\\pages\\coinswitch\\index.vue' /* webpackChunkName: "pages/coinswitch/index" */))
const _76cb09ec = () => interopDefault(import('..\\pages\\cross-chain\\index.vue' /* webpackChunkName: "pages/cross-chain/index" */))
const _6def7efe = () => interopDefault(import('..\\pages\\cross-chain\\index\\second.vue' /* webpackChunkName: "pages/cross-chain/index/second" */))
const _f9f70dc6 = () => interopDefault(import('..\\pages\\cross-chain\\index\\swap.vue' /* webpackChunkName: "pages/cross-chain/index/swap" */))
const _2296935c = () => interopDefault(import('..\\pages\\defi\\index.vue' /* webpackChunkName: "pages/defi/index" */))
const _04757675 = () => interopDefault(import('..\\pages\\defi\\index\\pools.vue' /* webpackChunkName: "pages/defi/index/pools" */))
const _bf90e7d4 = () => interopDefault(import('..\\pages\\defi\\index\\pools\\_pool.vue' /* webpackChunkName: "pages/defi/index/pools/_pool" */))
const _22071e65 = () => interopDefault(import('..\\pages\\defi\\index\\swap.vue' /* webpackChunkName: "pages/defi/index/swap" */))
const _adec8c32 = () => interopDefault(import('..\\pages\\docs.vue' /* webpackChunkName: "pages/docs" */))
const _03c0d4be = () => interopDefault(import('..\\pages\\index_old.vue' /* webpackChunkName: "pages/index_old" */))
const _2a7bb2a8 = () => interopDefault(import('..\\pages\\logos.vue' /* webpackChunkName: "pages/logos" */))
const _79d7a211 = () => interopDefault(import('..\\pages\\lp_new.vue' /* webpackChunkName: "pages/lp_new" */))
const _323fbc67 = () => interopDefault(import('..\\pages\\markets\\index.vue' /* webpackChunkName: "pages/markets/index" */))
const _41736c67 = () => interopDefault(import('..\\pages\\new_market.vue' /* webpackChunkName: "pages/new_market" */))
const _a3aa056e = () => interopDefault(import('..\\pages\\nft-market\\index.vue' /* webpackChunkName: "pages/nft-market/index" */))
const _1c1a94a0 = () => interopDefault(import('..\\pages\\otc\\index.vue' /* webpackChunkName: "pages/otc/index" */))
const _bd16fb3a = () => interopDefault(import('..\\pages\\swap\\index.vue' /* webpackChunkName: "pages/swap/index" */))
const _3179d8be = () => interopDefault(import('..\\pages\\test.vue' /* webpackChunkName: "pages/test" */))
const _34d9b59a = () => interopDefault(import('..\\pages\\trade\\index.vue' /* webpackChunkName: "pages/trade/index" */))
const _66c94a10 = () => interopDefault(import('..\\pages\\trade\\index\\_id.vue' /* webpackChunkName: "pages/trade/index/_id" */))
const _257587a5 = () => interopDefault(import('..\\pages\\wallet.vue' /* webpackChunkName: "pages/wallet" */))
const _7208d93d = () => interopDefault(import('..\\pages\\wallet\\index.vue' /* webpackChunkName: "pages/wallet/index" */))
const _17137b3f = () => interopDefault(import('..\\pages\\wallet\\history.vue' /* webpackChunkName: "pages/wallet/history" */))
const _827ea016 = () => interopDefault(import('..\\pages\\wallet\\liquidity_pools.vue' /* webpackChunkName: "pages/wallet/liquidity_pools" */))
const _089a1fc8 = () => interopDefault(import('..\\pages\\wallet\\nfts.vue' /* webpackChunkName: "pages/wallet/nfts" */))
const _5d950f55 = () => interopDefault(import('..\\pages\\wallet\\positions.vue' /* webpackChunkName: "pages/wallet/positions" */))
const _586beb90 = () => interopDefault(import('..\\pages\\wallet\\resources.vue' /* webpackChunkName: "pages/wallet/resources" */))
const _54400f88 = () => interopDefault(import('..\\pages\\wallet_new\\index.vue' /* webpackChunkName: "pages/wallet_new/index" */))
const _a9b8ad56 = () => interopDefault(import('..\\pages\\wallet_old\\index.vue' /* webpackChunkName: "pages/wallet_old/index" */))
const _12cd0dcc = () => interopDefault(import('..\\pages\\wallet_old\\index\\nfts.vue' /* webpackChunkName: "pages/wallet_old/index/nfts" */))
const _654b706f = () => interopDefault(import('..\\pages\\wallet_old\\index\\tokens.vue' /* webpackChunkName: "pages/wallet_old/index/tokens" */))
const _8d965098 = () => interopDefault(import('..\\pages\\wallet-inventory.vue' /* webpackChunkName: "pages/wallet-inventory" */))
const _6da12a4e = () => interopDefault(import('..\\pages\\wallet-inventory\\index.vue' /* webpackChunkName: "pages/wallet-inventory/index" */))
const _e44867e0 = () => interopDefault(import('..\\pages\\wallet-inventory\\history.vue' /* webpackChunkName: "pages/wallet-inventory/history" */))
const _5c179fc6 = () => interopDefault(import('..\\pages\\wallet-inventory\\liquidity_pools.vue' /* webpackChunkName: "pages/wallet-inventory/liquidity_pools" */))
const _d2986592 = () => interopDefault(import('..\\pages\\wallet-inventory\\nfts\\index.vue' /* webpackChunkName: "pages/wallet-inventory/nfts/index" */))
const _438c6fe6 = () => interopDefault(import('..\\pages\\wallet-inventory\\positions.vue' /* webpackChunkName: "pages/wallet-inventory/positions" */))
const _3e634c21 = () => interopDefault(import('..\\pages\\wallet-inventory\\resources.vue' /* webpackChunkName: "pages/wallet-inventory/resources" */))
const _27b332af = () => interopDefault(import('..\\pages\\wallet-inventory\\trade-offer.vue' /* webpackChunkName: "pages/wallet-inventory/trade-offer" */))
const _490bc32d = () => interopDefault(import('..\\pages\\coinswitch\\order.vue' /* webpackChunkName: "pages/coinswitch/order" */))
const _30ab335c = () => interopDefault(import('..\\pages\\nft-market\\collectionview.vue' /* webpackChunkName: "pages/nft-market/collectionview" */))
const _f4d08766 = () => interopDefault(import('..\\pages\\nft-market\\create\\index.vue' /* webpackChunkName: "pages/nft-market/create/index" */))
const _9e3f81a2 = () => interopDefault(import('..\\pages\\nft-market\\createcollection\\index.vue' /* webpackChunkName: "pages/nft-market/createcollection/index" */))
const _064afd37 = () => interopDefault(import('..\\pages\\nft-market\\createnft.vue' /* webpackChunkName: "pages/nft-market/createnft" */))
const _d9cf899a = () => interopDefault(import('..\\pages\\nft-market\\creatingschema.vue' /* webpackChunkName: "pages/nft-market/creatingschema" */))
const _6512e351 = () => interopDefault(import('..\\pages\\nft-market\\newtemplate.vue' /* webpackChunkName: "pages/nft-market/newtemplate" */))
const _745c3d1e = () => interopDefault(import('..\\pages\\nft-market\\nft-marketplace.vue' /* webpackChunkName: "pages/nft-market/nft-marketplace" */))
const _e6a3f5c8 = () => interopDefault(import('..\\pages\\nft-market\\nftburnable.vue' /* webpackChunkName: "pages/nft-market/nftburnable" */))
const _42cebab2 = () => interopDefault(import('..\\pages\\nft-market\\nftexplorer.vue' /* webpackChunkName: "pages/nft-market/nftexplorer" */))
const _37746e34 = () => interopDefault(import('..\\pages\\nft-market\\schematemplate.vue' /* webpackChunkName: "pages/nft-market/schematemplate" */))
const _1adf2fdf = () => interopDefault(import('..\\pages\\nft-market\\schemaview.vue' /* webpackChunkName: "pages/nft-market/schemaview" */))
const _efde92de = () => interopDefault(import('..\\pages\\nft-market\\tradeoffer.vue' /* webpackChunkName: "pages/nft-market/tradeoffer" */))
const _965fd68a = () => interopDefault(import('..\\pages\\swap\\create.vue' /* webpackChunkName: "pages/swap/create" */))
const _4a20a757 = () => interopDefault(import('..\\pages\\swap\\earn.vue' /* webpackChunkName: "pages/swap/earn" */))
const _73dbad02 = () => interopDefault(import('..\\pages\\nft-market\\createcollection\\_collection_name\\index.vue' /* webpackChunkName: "pages/nft-market/createcollection/_collection_name/index" */))
const _1cc6b81d = () => interopDefault(import('..\\pages\\nft-market\\order\\_id\\index.vue' /* webpackChunkName: "pages/nft-market/order/_id/index" */))
const _739304f4 = () => interopDefault(import('..\\pages\\otc\\order\\_id\\index.vue' /* webpackChunkName: "pages/otc/order/_id/index" */))
const _3b44a01d = () => interopDefault(import('..\\pages\\nft-market\\createcollection\\_collection_name\\createschema.vue' /* webpackChunkName: "pages/nft-market/createcollection/_collection_name/createschema" */))
const _71e4191a = () => interopDefault(import('..\\pages\\nft-market\\createcollection\\_collection_name\\_shema\\_schema_name\\index.vue' /* webpackChunkName: "pages/nft-market/createcollection/_collection_name/_shema/_schema_name/index" */))
const _0da55376 = () => interopDefault(import('..\\pages\\nft-market\\createcollection\\_collection_name\\_shema\\_schema_name\\createTemplate.vue' /* webpackChunkName: "pages/nft-market/createcollection/_collection_name/_shema/_schema_name/createTemplate" */))
const _75c7ea96 = () => interopDefault(import('..\\pages\\nfts\\_asset_id.vue' /* webpackChunkName: "pages/nfts/_asset_id" */))
const _1696fa56 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/about",
    component: _1241c0de,
    name: "about"
  }, {
    path: "/coinswitch",
    component: _304102b1,
    name: "coinswitch"
  }, {
    path: "/cross-chain",
    component: _76cb09ec,
    name: "cross-chain",
    children: [{
      path: "second",
      component: _6def7efe,
      name: "cross-chain-index-second"
    }, {
      path: "swap",
      component: _f9f70dc6,
      name: "cross-chain-index-swap"
    }]
  }, {
    path: "/defi",
    component: _2296935c,
    name: "defi",
    children: [{
      path: "pools",
      component: _04757675,
      name: "defi-index-pools",
      children: [{
        path: ":pool?",
        component: _bf90e7d4,
        name: "defi-index-pools-pool"
      }]
    }, {
      path: "swap",
      component: _22071e65,
      name: "defi-index-swap"
    }]
  }, {
    path: "/docs",
    component: _adec8c32,
    name: "docs"
  }, {
    path: "/index_old",
    component: _03c0d4be,
    name: "index_old"
  }, {
    path: "/logos",
    component: _2a7bb2a8,
    name: "logos"
  }, {
    path: "/lp_new",
    component: _79d7a211,
    name: "lp_new"
  }, {
    path: "/markets",
    component: _323fbc67,
    name: "markets"
  }, {
    path: "/new_market",
    component: _41736c67,
    name: "new_market"
  }, {
    path: "/nft-market",
    component: _a3aa056e,
    name: "nft-market"
  }, {
    path: "/otc",
    component: _1c1a94a0,
    name: "otc"
  }, {
    path: "/swap",
    component: _bd16fb3a,
    name: "swap"
  }, {
    path: "/test",
    component: _3179d8be,
    name: "test"
  }, {
    path: "/trade",
    component: _34d9b59a,
    name: "trade",
    children: [{
      path: ":id?",
      component: _66c94a10,
      name: "trade-index-id"
    }]
  }, {
    path: "/wallet",
    component: _257587a5,
    children: [{
      path: "",
      component: _7208d93d,
      name: "wallet"
    }, {
      path: "history",
      component: _17137b3f,
      name: "wallet-history"
    }, {
      path: "liquidity_pools",
      component: _827ea016,
      name: "wallet-liquidity_pools"
    }, {
      path: "nfts",
      component: _089a1fc8,
      name: "wallet-nfts"
    }, {
      path: "positions",
      component: _5d950f55,
      name: "wallet-positions"
    }, {
      path: "resources",
      component: _586beb90,
      name: "wallet-resources"
    }]
  }, {
    path: "/wallet_new",
    component: _54400f88,
    name: "wallet_new"
  }, {
    path: "/wallet_old",
    component: _a9b8ad56,
    name: "wallet_old",
    children: [{
      path: "nfts",
      component: _12cd0dcc,
      name: "wallet_old-index-nfts"
    }, {
      path: "tokens",
      component: _654b706f,
      name: "wallet_old-index-tokens"
    }]
  }, {
    path: "/wallet-inventory",
    component: _8d965098,
    children: [{
      path: "",
      component: _6da12a4e,
      name: "wallet-inventory"
    }, {
      path: "history",
      component: _e44867e0,
      name: "wallet-inventory-history"
    }, {
      path: "liquidity_pools",
      component: _5c179fc6,
      name: "wallet-inventory-liquidity_pools"
    }, {
      path: "nfts",
      component: _d2986592,
      name: "wallet-inventory-nfts"
    }, {
      path: "positions",
      component: _438c6fe6,
      name: "wallet-inventory-positions"
    }, {
      path: "resources",
      component: _3e634c21,
      name: "wallet-inventory-resources"
    }, {
      path: "trade-offer",
      component: _27b332af,
      name: "wallet-inventory-trade-offer"
    }]
  }, {
    path: "/coinswitch/order",
    component: _490bc32d,
    name: "coinswitch-order"
  }, {
    path: "/nft-market/collectionview",
    component: _30ab335c,
    name: "nft-market-collectionview"
  }, {
    path: "/nft-market/create",
    component: _f4d08766,
    name: "nft-market-create"
  }, {
    path: "/nft-market/createcollection",
    component: _9e3f81a2,
    name: "nft-market-createcollection"
  }, {
    path: "/nft-market/createnft",
    component: _064afd37,
    name: "nft-market-createnft"
  }, {
    path: "/nft-market/creatingschema",
    component: _d9cf899a,
    name: "nft-market-creatingschema"
  }, {
    path: "/nft-market/newtemplate",
    component: _6512e351,
    name: "nft-market-newtemplate"
  }, {
    path: "/nft-market/nft-marketplace",
    component: _745c3d1e,
    name: "nft-market-nft-marketplace"
  }, {
    path: "/nft-market/nftburnable",
    component: _e6a3f5c8,
    name: "nft-market-nftburnable"
  }, {
    path: "/nft-market/nftexplorer",
    component: _42cebab2,
    name: "nft-market-nftexplorer"
  }, {
    path: "/nft-market/schematemplate",
    component: _37746e34,
    name: "nft-market-schematemplate"
  }, {
    path: "/nft-market/schemaview",
    component: _1adf2fdf,
    name: "nft-market-schemaview"
  }, {
    path: "/nft-market/tradeoffer",
    component: _efde92de,
    name: "nft-market-tradeoffer"
  }, {
    path: "/swap/create",
    component: _965fd68a,
    name: "swap-create"
  }, {
    path: "/swap/earn",
    component: _4a20a757,
    name: "swap-earn"
  }, {
    path: "/nft-market/createcollection/:collection_name",
    component: _73dbad02,
    name: "nft-market-createcollection-collection_name"
  }, {
    path: "/nft-market/order/:id",
    component: _1cc6b81d,
    name: "nft-market-order-id"
  }, {
    path: "/otc/order/:id",
    component: _739304f4,
    name: "otc-order-id"
  }, {
    path: "/nft-market/createcollection/:collection_name/createschema",
    component: _3b44a01d,
    name: "nft-market-createcollection-collection_name-createschema"
  }, {
    path: "/nft-market/createcollection/:collection_name/:shema/:schema_name",
    component: _71e4191a,
    name: "nft-market-createcollection-collection_name-shema-schema_name"
  }, {
    path: "/nft-market/createcollection/:collection_name/:shema/:schema_name/createTemplate",
    component: _0da55376,
    name: "nft-market-createcollection-collection_name-shema-schema_name-createTemplate"
  }, {
    path: "/nfts/:asset_id?",
    component: _75c7ea96,
    name: "nfts-asset_id"
  }, {
    path: "/",
    component: _1696fa56,
    name: "index"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
