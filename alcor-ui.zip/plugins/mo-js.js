import Vue from 'vue'
import Vuemo from '@azukisiromochi/vue-mo.js'

import NoSSR from 'vue-no-ssr'
Vue.use(Vuemo)
Vue.component('no-ssr', NoSSR)
