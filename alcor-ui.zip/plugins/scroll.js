import Vue from 'vue'

import VueScrollTo from 'vue-scrollto'

export default () => {
  Vue.use(VueScrollTo)
}